var pClass = null;
var pSubject  = null;
var pSugestions  = null;

$(function () {

    chrome.runtime.sendMessage({todo:"serverResponse"});

    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.executeScript(
            tabs[0].id, 
            {code: 'console.log("teste");'}
        );
    });

    chrome.storage.sync.get('classValue', function(data){
        
        classValue = data.classValue.value;
        classDesc = data.classValue.desc;
        
        var subjectValue = null;
        chrome.storage.sync.get('subjectValue', function(data){
            
            subjectValue = data.subjectValue;

            $('span.ci-subject').text(subjectValue);
            $('span.ci-class').text(classDesc);
            
            /** CHECK IN SERVER */
            checkInServer(classValue, subjectValue);

        });

    });
})
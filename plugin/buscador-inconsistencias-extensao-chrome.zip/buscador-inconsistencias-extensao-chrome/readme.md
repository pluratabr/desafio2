# Instalação do Plugin
1. Faça o donwload do arquivo zip clicando [aqui](https://https://hackathon.plurata.com.br/plugin/buscador-inconsistencias-extensao-chrome.zip) AJUSTAR O LINK ANTES DO COMMIT FINAL
1. Extraia o aqruivo;
2. Acesse chrome://extensions/;
3. No canto superior direito, ative o Modo do desenvolvedor;
4. Clique em Carregar sem compactação e selecione a pasta que foi descompactada;
5. Encontre e selecione a pasta do app ou extensão.;
6. Pronto a extensão foi instalada.

# Utilização
1. Acesse: https://pjetrn1g.trf1.jus.br/
2. Escolha um dos perfis para fazer login:
 - Advogado : 
    * Usuário : 05302968452
    * Senha: 05302968452

- Como servidor (diretor)
    * Usuário: 73200735015
    * Senha: 73200735015